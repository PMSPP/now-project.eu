 # plastic-kit

YEAH, you made it into the download-kit!
Start with folder 1. Read the introduction text and make sure to watch the videos from our website.

Need support? Read this: https://preciousplastic.com/en/videos/questions
If you have any questions visit our forums: https://davehakkens.nl/community/

Good luck!!
